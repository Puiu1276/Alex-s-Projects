package org.apoo;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.jetbrains.annotations.NotNull;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Date;

@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Asset implements Serializable{
    @EqualsAndHashCode.Include
    @NotNull
    @Id
    @GeneratedValue
    private Integer assetID;
    private String assetName;
    private String assetDescriere;
    private Integer costAsset;
    private AssetType AssetType;

    public Asset(Integer assetID, String assetName, String assetDescriere,
                  Integer costAsset, AssetType AssetType) {
        this.assetID = assetID;
        this.assetName = assetName;
        this.assetDescriere = assetDescriere;
        this.AssetType = AssetType;
        this.costAsset = costAsset;
    }


    public enum AssetType {IMOBILIZARICORPORALE, STOCURI};
    public enum stareAsset {NOU_INREGISTRAT, IN_ASTEPTARE, ALOCAT, ABANDONAT, IN_REVIZIE, ARHIVAT};


}
