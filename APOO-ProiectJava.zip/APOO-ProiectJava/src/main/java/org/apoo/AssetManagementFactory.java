package org.apoo;

import org.apoo.observer.MaintenanceObserver;
import org.apoo.strategy.AssetValuationStrategy;

// Factory Method pentru crearea de strategii și monitoare
public abstract class AssetManagementFactory {
    abstract AssetValuationStrategy createValuationStrategy();
    abstract MaintenanceObserver createMaintenanceMonitor();
}
