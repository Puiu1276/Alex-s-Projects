package org.apoo;

import org.apoo.observer.MaintenanceCostMonitor;
import org.apoo.observer.MaintenanceObserver;
import org.apoo.strategy.AssetValuationStrategy;
import org.apoo.strategy.MarketConditionValuation;

public class ConcreteAssetManagementFactory extends AssetManagementFactory {
    @Override
    AssetValuationStrategy createValuationStrategy() {
        return new MarketConditionValuation();
    }

    @Override
    MaintenanceObserver createMaintenanceMonitor() {
        return new MaintenanceCostMonitor();
    }
}
