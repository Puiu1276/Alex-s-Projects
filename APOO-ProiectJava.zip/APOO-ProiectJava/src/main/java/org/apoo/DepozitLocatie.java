package org.apoo;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.jetbrains.annotations.NotNull;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.io.Serializable;

@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class DepozitLocatie implements Serializable {
    @EqualsAndHashCode.Include
    @NotNull
    @Id
    @GeneratedValue
    private Integer depozitID;
    private String depozitName;
    private String depozitDescriere;
    private String depozitAdresa;

    public enum stareDepozit {GOL, PARTIAL_PLIN,  PLIN, IN_REASEZARE};

}
