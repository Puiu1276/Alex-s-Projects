package org.apoo;

import org.apoo.singleton.AssetEvaluationService;
import org.apoo.observer.MaintenanceObserver;
import org.apoo.strategy.AssetValuationStrategy;

public class Main {
    public static void main(String[] args) {
        // Creare assetFactory și obiecte pentru managementul activelor
        ConcreteAssetManagementFactory factory = new ConcreteAssetManagementFactory();
        AssetValuationStrategy valuationStrategy = factory.createValuationStrategy();
        MaintenanceObserver maintenanceObserver = factory.createMaintenanceMonitor();

        // Creare activ și evaluare
        Asset asset = new Asset(1, "Depozit nr 1", "Depozitul din Valea Lupului",  12000, Asset.AssetType.IMOBILIZARICORPORALE); // ID și cost
        AssetEvaluationService evaluationService = AssetEvaluationService.getInstance();
        evaluationService.evaluateAssets(asset, valuationStrategy);

        // Adăugarea observer-ului pentru monitorizarea activului
        maintenanceObserver.update(asset);    }
}