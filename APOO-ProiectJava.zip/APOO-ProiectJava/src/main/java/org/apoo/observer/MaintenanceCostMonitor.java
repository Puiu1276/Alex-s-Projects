package org.apoo.observer;

import org.apoo.Asset;
import org.apoo.observer.MaintenanceObserver;

public class MaintenanceCostMonitor implements MaintenanceObserver {
    @Override
    public void update(Asset asset) {
        System.out.println("Actualizarea costurilor de întreținere pentru activul cu ID: " + asset.getAssetID());
    }
}
