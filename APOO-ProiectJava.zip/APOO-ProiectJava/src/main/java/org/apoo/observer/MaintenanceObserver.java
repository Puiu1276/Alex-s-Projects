package org.apoo.observer;

import org.apoo.Asset;

public interface MaintenanceObserver {
    void update(Asset asset);
}
