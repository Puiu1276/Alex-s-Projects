package org.apoo.singleton;

// Singleton Pattern pentru un serviciu de evaluare centralizat

import org.apoo.Asset;
import org.apoo.strategy.AssetValuationStrategy;

public class AssetEvaluationService {
    private static AssetEvaluationService instance = new AssetEvaluationService();

    private AssetEvaluationService() {}

    public static AssetEvaluationService getInstance() {
        return instance;
    }

    public void evaluateAssets(Asset asset, AssetValuationStrategy strategy) {
        double value = strategy.evaluate(asset);
        System.out.println("Valoarea evaluată pentru activul cu ID: " + asset.getAssetID() + " cu numele " + asset.getAssetName() + " este: " + value);
    }
}
