package org.apoo.strategy;

import org.apoo.Asset;

public interface AssetValuationStrategy {
    double evaluate(Asset asset);
}
