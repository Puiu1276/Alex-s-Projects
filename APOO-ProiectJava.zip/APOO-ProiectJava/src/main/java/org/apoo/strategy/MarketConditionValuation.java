package org.apoo.strategy;

import org.apoo.Asset;
import org.apoo.strategy.AssetValuationStrategy;

public class MarketConditionValuation  implements AssetValuationStrategy {
    @Override
    public double evaluate(Asset asset) {
        return asset.getCostAsset() * 2; //spre exemplu, sa zicem o crestere de 20%
    }
}
