package org.scrum.domain.REST;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.logging.Logger;


//  http://localhost:8080/scrum/rest/service/workflow/newAsset/{assetName}


@RestController
@RequestMapping("/rest/service/workflow") // REST.RPC Style
@Transactional
public class AssetRest {
    private static Logger logger = Logger.getLogger(AssetRest.class.getName());

    @Autowired
    private IAssetRest assetRest;

    @RequestMapping(
            path = "/newAsset/{assetName}",
            method = RequestMethod.GET)
    @ResponseBody
    public Integer createNewAsset(
            @PathVariable("assetName") String assetName)
    {
        Integer id = assetRest.createNewAsset(assetName);
        return id;
    }
}
