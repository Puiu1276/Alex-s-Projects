package org.scrum.domain.REST;

import org.scrum.domain.asset.Asset;
import org.scrum.domain.services.IAngajatEntityFactory;
import org.scrum.domain.services.IAngajatEntityRepository;
import org.scrum.domain.services.IAssetEntityFactory;
import org.scrum.domain.services.IAssetEntityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class AssetRestImpl implements IAssetRest{
    @Autowired
    private IAssetEntityRepository entityRepository;

    @Autowired
    private IAssetEntityFactory entityFactory;

    @Autowired
    private ApplicationEventPublisher applicationEventPublisher;
    @Override
    public Integer createNewAsset(String assetName) {
        Asset asset = entityFactory.buildAsset(assetName);

        // Validate Event to invoke Validation Service
        // applicationEventPublisher.publishEvent(new DomainEvent(this, project));

        entityRepository.add(asset);
        return asset.getAssetID();
    }
}
