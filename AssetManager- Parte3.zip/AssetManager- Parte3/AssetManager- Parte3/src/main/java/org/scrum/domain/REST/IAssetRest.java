package org.scrum.domain.REST;

public interface IAssetRest {
    //creaza un nou asset
    Integer createNewAsset(String assetName);
}
