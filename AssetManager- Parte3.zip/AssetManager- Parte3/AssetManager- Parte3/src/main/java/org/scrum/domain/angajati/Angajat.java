package org.scrum.domain.angajati;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import org.scrum.domain.asset.Asset;
import org.scrum.domain.operatiune.Operatiune;

import java.io.Serializable;

import static jakarta.persistence.FetchType.EAGER;

@Entity
@Inheritance(strategy= InheritanceType.JOINED)

public class Angajat implements Comparable<Angajat>, Serializable {
    @Id
    @GeneratedValue
    private Integer angajatID;

    private String angajatName;
    @JsonIgnore
    private Role role;
    @JsonIgnore
    private String userName;
    @JsonIgnore
    private String password;

    @ManyToOne
    private Asset asset;
    @JsonIgnore
    @OneToOne(cascade = CascadeType.ALL, fetch = EAGER, orphanRemoval = false)
    private Operatiune opeatiuneActiv;
    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public Integer getAngajatID() {
        return angajatID;
    }
    public void setAngajatID(Integer angajatID) {
        this.angajatID = angajatID;
    }
    public String getAngajatName() {
        return angajatName;
    }
    public void setAngajatName(String name) {
        this.angajatName = angajatName;
    }
    public Role getRole() {
        return role;
    }
    public void setRole(Role role) {
        this.role = role;
    }

    public Angajat() {
        super();
    }
    public Angajat(Integer angajatID, String name) {
        super();
        this.angajatID = angajatID;
        this.angajatName = name;
    }
    public Angajat(Integer angajatID, String name, Role role) {
        super();
        this.angajatID = angajatID;
        this.angajatName = name;
        this.role = role;
    }


    public Angajat(Integer angajatID, String name, String userName,
                   String password) {
        super();
        this.angajatID = angajatID;
        this.angajatName = name;
        this.userName = userName;
        this.password = password;
    }


    // caz supra-incarcare
    private String abilities;

    public String getAbilities() {
        return abilities;
    }
    public void setAbilities(String abilities) {
        this.abilities = abilities;
    }
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result
                + ((angajatID == null) ? 0 : angajatID.hashCode());
        result = prime * result + ((role == null) ? 0 : role.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
//		if (getClass() != obj.getClass())
//			return false;
        Angajat other = (Angajat) obj;
        if (angajatID == null) {
            if (other.angajatID != null)
                return false;
        } else if (!angajatID.equals(other.angajatID))
            return false;
        if (role != other.role)
            return false;
        return true;
    }

    @Override
    public int compareTo(Angajat other) {
        if (this.equals(other))
            return 0;
        return this.getAngajatID().compareTo(other.getAngajatID());
    }
    @Override
    public String toString() {
        return "Member [memberID=" + angajatID + ", memberName=" + angajatName
                + ", userName=" + userName + ", password=" + password + "]";
    }

    public enum Role{
        MANAGER, ADMINISTRATOR;
    }
}
