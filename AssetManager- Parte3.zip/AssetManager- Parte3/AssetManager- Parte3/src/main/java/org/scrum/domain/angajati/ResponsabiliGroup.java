package org.scrum.domain.angajati;

import lombok.Value;

@Value
public class ResponsabiliGroup {
    private String groupName;
}
