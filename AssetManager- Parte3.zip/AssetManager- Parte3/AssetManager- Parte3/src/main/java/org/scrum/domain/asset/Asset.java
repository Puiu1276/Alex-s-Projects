package org.scrum.domain.asset;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.scrum.domain.angajati.Angajat;
import org.scrum.domain.location.Location;
import org.scrum.domain.operatiune.Operatiune;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import static jakarta.persistence.FetchType.EAGER;

@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity
@Inheritance(strategy= InheritanceType.JOINED)

public class Asset implements Serializable, Comparable<Asset>{
    @EqualsAndHashCode.Include
    @Min(1) @NotNull(message = " AssetID is required!")
    @Id
    @GeneratedValue
    private Integer assetID;
    private AssetType AssetType;
    private Integer valoareAsset;
    @NotNull(message = " Asset Name is required!")
    @Size(min=1, message = " Asset must have an explicit name!")
    private String assetName;
    @JsonIgnore
    @OneToOne(cascade = CascadeType.ALL, fetch = EAGER, orphanRemoval = false)
    private Operatiune opeariune;
    @JsonIgnore
    @OneToOne(cascade = CascadeType.ALL, fetch = EAGER, orphanRemoval = false)
    private Location currentLocation;
    @JsonIgnore
    @OneToOne(cascade = CascadeType.ALL, fetch = EAGER, orphanRemoval = false)
    private Location destinatieLocatie;
    @JsonIgnore
    @OneToMany(mappedBy="asset",
            cascade = CascadeType.ALL,
            fetch = FetchType.EAGER,
            orphanRemoval = true)
    private List<Angajat> angajat = new ArrayList<>();

    @Convert(converter = AssetGroupConverter.class)
    private AssetGroup assetGroup;

    public Integer getAssetID() {
        return assetID;
    }

    public void setAssetID(Integer assetID) {
        this.assetID = assetID;
    }

    public Asset.AssetType getAssetType() {
        return AssetType;
    }

    public void setAssetType(Asset.AssetType assetType) {
        AssetType = assetType;
    }

    public Integer getValoareAsset() {
        return valoareAsset;
    }

    public void setValoareAsset(Integer valoareAsset) {
        this.valoareAsset = valoareAsset;
    }

    public String getAssetName() {
        return assetName;
    }

    public void setAssetName(String assetName) {
        this.assetName = assetName;
    }

    public Operatiune getOpeariune() {
        return opeariune;
    }

    public void setOpeariune(Operatiune opeariune) {
        this.opeariune = opeariune;
    }

    public Location getCurrentLocation() {
        return currentLocation;
    }

    public void setCurrentLocation(Location currentLocation) {
        this.currentLocation = currentLocation;
    }

    public Location getDestinatieLocatie() {
        return destinatieLocatie;
    }

    public void setDestinatieLocatie(Location destinatieLocatie) {
        this.destinatieLocatie = destinatieLocatie;
    }

    public List<Angajat> getAngajat() {
        return angajat;
    }

    public void setAngajat(Angajat angajat) {
        if (this.angajat == null) {
            this.angajat = new ArrayList<>();
        }
        this.angajat.add(angajat);
    }

    public AssetGroup getAssetGroup() {
        return assetGroup;
    }

    public void setAssetGroup(AssetGroup assetGroup) {
        this.assetGroup = assetGroup;
    }

    public Integer getOperatiuniCount() {
        return OperatiuniCount;
    }

    public void setOperatiuniCount(Integer operatiuniCount) {
        OperatiuniCount = operatiuniCount;
    }

    @Override
    public String toString() {
        return "Asset{" +
                "assetID=" + assetID +
                ", AssetType=" + AssetType +
                ", valoareAsset=" + valoareAsset +
                ", assetName='" + assetName + '\'' +
                ", opeariune=" + opeariune +
                ", currentLocation=" + currentLocation +
                ", destinatieLocatie=" + destinatieLocatie +
                ", responsabil=" + angajat +
                ", OperatiuniCount=" + OperatiuniCount +
                '}';
    }

    @Override
    public int compareTo(Asset other) {
        return this.assetID.compareTo(other.getAssetID());
    }

    @Transient
    protected Integer OperatiuniCount = 0;

    @PrePersist
    public void onPrePersist() {
        System.out.println(">>> JPA Triggers: @PrePersist");
        this.setOperatiuniCount((this.angajat ==null)? 0 : this.angajat.size());
    }

    @PreUpdate
    public void onPreUpdate() {
        System.out.println(">>> JPA Triggers: @PreUpdate");
        this.setOperatiuniCount((this.angajat ==null)? 0 : this.angajat.size());
    }

    @PreRemove
    public void onPreRemove() {
        System.out.println(">>> JPA Triggers: @PreRemove");
    }

    public void addResponsabil (String memberName){
        this.angajat.add(new Angajat(null, memberName));
    }

    public void add(Asset testAsset) {
    }

    public Asset(Integer assetID, String assetName, Asset.AssetType stocuri) {
        super();
        this.assetID = assetID;
        this.assetName = assetName;
    }
    public Asset(Integer assetID, String assetName, Integer valoareAsset, Operatiune opeariune, Location currentLocation, Location destinatieLocatie) {
        super();
        this.assetID = assetID;
        this.assetName = assetName;
        this.valoareAsset = valoareAsset;
        this.opeariune = opeariune;
        this.currentLocation = currentLocation;
        this.destinatieLocatie = destinatieLocatie;
    }
    public Asset() {
        super();
    }

    public enum AssetType {IMOBILIZARICORPORALE, STOCURI};

}
