package org.scrum.domain.asset;

import lombok.Value;

@Value
public class AssetGroup {
    private String groupName;
}
