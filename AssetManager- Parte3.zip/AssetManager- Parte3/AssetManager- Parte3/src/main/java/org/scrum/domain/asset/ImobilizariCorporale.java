package org.scrum.domain.asset;

import jakarta.persistence.Entity;

@Entity
public class ImobilizariCorporale extends Asset{

    private Integer numarImobilizareCorporala;

    public Integer getNumarImobilizareCorporala(){
        return numarImobilizareCorporala;
    }

    public void setNumarImobilizareCorporala(Integer numarImobilizareCorporala){
        this.numarImobilizareCorporala = numarImobilizareCorporala;
    }

    public ImobilizariCorporale (Integer assetID, String assetName,
                    Integer numarImobilizareCorporala){
        super(assetID, assetName, Asset.AssetType.STOCURI);
        this.numarImobilizareCorporala = numarImobilizareCorporala;
    }

    public ImobilizariCorporale() {
        super(null, "Angajat sample for next ID ...", Asset.AssetType.STOCURI);
        super.setAssetType(AssetType.IMOBILIZARICORPORALE);
    }

    public void setAssetType(AssetType assetType) {
        throw new Error("Proprietatea tip nu poate fi schimbata!");
    }

}
