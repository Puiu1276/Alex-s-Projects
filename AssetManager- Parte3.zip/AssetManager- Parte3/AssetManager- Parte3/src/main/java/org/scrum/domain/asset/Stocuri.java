package org.scrum.domain.asset;

import jakarta.persistence.Entity;

@Entity
public class Stocuri extends Asset{

    private Integer numarStoc;

    public Integer getNumarStoc(){
        return numarStoc;
    }

    public void setNumarStoc(Integer NumarStoc){
        this.numarStoc = numarStoc;
    }

    public Stocuri (Integer assetID, String assetName,
                    Integer numarStoc){
        super(assetID, assetName, Asset.AssetType.STOCURI);
        this.numarStoc = numarStoc;
    }

    public Stocuri() {
        super(null, "Angajat sample for next ID ...", Asset.AssetType.STOCURI);
        super.setAssetType(AssetType.STOCURI);
    }

    public void setAssetType(AssetType assetType) {
        throw new Error("Proprietatea tip nu poate fi schimbata!");
    }
}
