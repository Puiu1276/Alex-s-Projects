package org.scrum.domain.httpApp;

// http://localhost:8080/scrum/rest/data/angajati

import org.scrum.domain.asset.Asset;
import org.scrum.domain.services.IAngajatEntityRepository;
import org.scrum.domain.services.IAssetEntityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.logging.Logger;

@RestController
@RequestMapping("/rest/data/assets") // REST.Resource Style
@Transactional
public class AssetAppServiceRest {
    private static Logger logger = Logger.getLogger(AssetAppServiceRest.class.getName());

    @Autowired
    private IAssetEntityRepository assetEntityRepository;

    @Autowired
    private IAssetDTOFactory assetDTOFactory;

    //@GetMapping
    @RequestMapping(method = RequestMethod.GET,
            produces = {MediaType.APPLICATION_XML_VALUE,
                    MediaType.APPLICATION_JSON_VALUE})

    @ResponseBody
    public Collection<Asset> toCollection() {
        logger.info("**** DEBUG SPRING-MVC-REST toCollection() >>> get All DTO assets::");
        List<Asset> assets= (List<Asset>) assetEntityRepository.toCollection();
        assets.forEach(a -> logger.info(">>> Project Entites: " + a));

        List<Asset> assetDTOs = new ArrayList<>();
        assetDTOs = assetDTOFactory.toDTOList(assets);
        assetDTOs.forEach(a -> logger.info(">>> Asset DTO: " + a));

        return assetDTOs;
    }
}
