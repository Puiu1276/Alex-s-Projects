package org.scrum.domain.httpApp;

import lombok.*;
import org.scrum.domain.asset.Asset;

@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@RequiredArgsConstructor
@NoArgsConstructor
public class AssetDTO {
    @EqualsAndHashCode.Include
    @NonNull
    private Integer assetID;
    @NonNull private String assetName;

    @NonNull private Asset.AssetType assetType;
}
