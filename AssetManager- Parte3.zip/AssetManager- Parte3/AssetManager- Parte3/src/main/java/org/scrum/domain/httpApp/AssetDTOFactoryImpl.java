package org.scrum.domain.httpApp;

import org.scrum.domain.asset.Asset;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.logging.Logger;

@Service
public class AssetDTOFactoryImpl implements IAssetDTOFactory{
    private static Logger logger = Logger.getLogger(AssetDTOFactoryImpl.class.getName());

    // Default constructor
    public AssetDTOFactoryImpl() {
        logger.info(">>> BEAN: AssetDTOFactoryEJB instantiated!");
    }

    /* DTO Project Logic*/
    @Override
    public Asset toDTO(Asset asset) {
        Asset assetDTO = new Asset(asset.getAssetID(), asset.getAssetName(), asset.getAssetType());
        return assetDTO;
    }

    @Override
    public Asset toDTOAggregate(Asset asset) {
        if (asset == null)
            return null;
        Asset assetDTO = toDTO(asset);

        return assetDTO;    }

    @Override
    public List<Asset> toDTOList(Collection<Asset> assets) {
        List<Asset> assetDTOList = new ArrayList<>();
        for(Asset a: assets){
            assetDTOList.add(toDTO(a));
        }
        return assetDTOList;    }

    @Override
    public List<Asset> toDTOListOfAggregates(Collection<Asset> assets) {
        List<Asset> assetDTOList = new ArrayList<>();
        for(Asset p: assets){
            assetDTOList.add(toDTOAggregate(p));
        }
        return assetDTOList;    }

    @Override
    public Collection<Asset> toDTOs(Collection<Asset> assets) {
        List<Asset> assetDTOList = new ArrayList<>();
        for(Asset a: assets){
            assetDTOList.add(toDTO(a));
        }
        return assetDTOList;    }
}
