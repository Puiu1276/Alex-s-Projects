package org.scrum.domain.httpApp;

import org.scrum.domain.asset.Asset;

import java.util.Collection;
import java.util.List;

public interface IAssetDTOFactory {
    Asset toDTO(Asset asset);

    Asset toDTOAggregate(Asset asset);

    List<Asset> toDTOList(Collection<Asset> assets);

    List<Asset> toDTOListOfAggregates(Collection<Asset> assets);

    Collection<Asset> toDTOs(Collection<Asset> assets);
}
