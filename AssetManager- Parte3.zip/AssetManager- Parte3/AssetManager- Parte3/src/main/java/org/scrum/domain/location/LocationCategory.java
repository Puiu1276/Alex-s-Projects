package org.scrum.domain.location;

public enum LocationCategory {
    DEPOZIT, BIROU;
}
