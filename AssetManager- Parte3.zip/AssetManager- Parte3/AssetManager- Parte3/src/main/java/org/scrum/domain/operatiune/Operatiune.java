package org.scrum.domain.operatiune;


import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.scrum.domain.angajati.Angajat;
import org.scrum.domain.asset.Asset;
import org.scrum.domain.location.Location;

import java.util.Date;

import static jakarta.persistence.FetchType.EAGER;

@Data
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity
@Inheritance(strategy= InheritanceType.JOINED)

public class Operatiune {
    @EqualsAndHashCode.Include
    @Min(1) @NotNull(message = " OperatiuneID is required!")
    @Id
    @GeneratedValue
    private Integer operatiuneID;
    private OperatiuneTip tipOpeariune;
    private String descriereOperatiune;
    private Location locatieCurenta;
    private Location destinatieLocatie;
    @NotNull(message = " OpeariuneDate is required!")
    @Temporal(TemporalType.DATE)
    private Date operatiuneDate;

    @OneToOne(cascade = CascadeType.ALL, fetch = EAGER, orphanRemoval = false)
    private Angajat angajatOpeariune;

    @OneToOne(cascade = CascadeType.ALL, fetch = EAGER, orphanRemoval = false)
    private Asset assetOperat;


    public Operatiune(Integer operatiuneID, String descriereOperatiune, OperatiuneTip tipOpeariune) {
        super();
        this.operatiuneID = operatiuneID;
        this.descriereOperatiune = descriereOperatiune;
        this.tipOpeariune = tipOpeariune;
    }
    public Operatiune(String descriereOperatiune, Location locatieCurenta) {
        super();
        this.operatiuneID = operatiuneID;
        this.descriereOperatiune = descriereOperatiune;
        this.tipOpeariune = tipOpeariune;
        this.locatieCurenta = locatieCurenta;
        this.destinatieLocatie = destinatieLocatie;
    }

    @Override
    public String toString() {
        return "Opeariune{" +
                "operatiuneID=" + operatiuneID +
                ", descriereOperatiune='" + descriereOperatiune + '\'' +
                ", operatiuneDate=" + operatiuneDate +
                ", responsabilOpeariune=" + angajatOpeariune +
                ", assetOperat=" + assetOperat +
                '}';
    }

    public enum OperatiuneTip {
        IMPRUMUT, TRANSFER;
    }
}
