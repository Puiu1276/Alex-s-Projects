package org.scrum.domain.operatiune;

import jakarta.persistence.Entity;
import org.scrum.domain.asset.Asset;
import org.scrum.domain.location.Location;

@Entity
public class Transfer extends Operatiune {


    public Transfer() {
        super(null, "Operatiune sample for next ID ...", OperatiuneTip.TRANSFER);
    }

    public Transfer transferAsset(Asset assetID, Location locatieCurenta, Location destinatieLocatie) {
        if (!checkIfAssetExists(assetID)) {
            throw new RuntimeException("Asset with ID " + assetID + " does not exist.");
        }
        // Crează o nouă operație de transfer
        Transfer transferOperation = new Transfer();
        transferOperation.setTipOpeariune(OperatiuneTip.TRANSFER);
        transferOperation.setDescriereOperatiune("Transfer of asset " + assetID + " from " + locatieCurenta + " to " + destinatieLocatie);
        transferOperation.setAssetOperat(assetID);
        transferOperation.setLocatieCurenta(locatieCurenta);
        transferOperation.setDestinatieLocatie(destinatieLocatie);

        return transferOperation;

    }

    private boolean checkIfAssetExists(Asset assetID) {
        return true;
    }
}
