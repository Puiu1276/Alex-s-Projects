package org.scrum.domain.services;

import org.scrum.domain.angajati.Angajat;

public interface IAngajatEntityFactory {
    // Dependencies to get IDs
    public void setAngajatEntityRepository(IAngajatEntityRepository repository);

    public Angajat buildAngajat(String angajatName);
    public IAngajatEntityRepository getAngajatEntityRepository();
}
