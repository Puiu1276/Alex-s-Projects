package org.scrum.domain.services;

import org.scrum.domain.angajati.Angajat;
import org.scrum.domain.repo.EntityRepository;

import java.util.List;

public interface IAngajatEntityRepository extends EntityRepository<Angajat> {
    public Integer getNextID() ;

    //
    List<Angajat> findByAngajatName(String name);
}
