package org.scrum.domain.services;

import org.scrum.domain.angajati.Angajat;
import org.scrum.domain.asset.Asset;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface IAssetDomainService {

    public List<Angajat> getAngajatiAsset(Asset asset);

    public Integer getAngajatiAssetCount(Asset asset);

    public List<Angajat> getAngajatiAsset(Integer assetID);
    public Integer getAngajatiAssetCount(Integer assetID);

    public Angajat getAngajatAsset(Asset asset, String angajatName);
    public void setAssetEntityRepository(IAssetEntityRepository repository);
}
