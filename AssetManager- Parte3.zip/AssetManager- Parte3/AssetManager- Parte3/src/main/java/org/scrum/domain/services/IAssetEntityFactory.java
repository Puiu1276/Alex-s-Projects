package org.scrum.domain.services;

import org.scrum.domain.asset.Asset;

public interface IAssetEntityFactory {
    public void setAssetEntityRepository(IAssetEntityRepository repository);

    public Asset buildAsset(String assetName);
    public IAssetEntityRepository getAssetEntityRepository();
}
