package org.scrum.domain.services;

import org.scrum.domain.asset.Asset;
import org.scrum.domain.repo.EntityRepository;

import java.util.List;

public interface IAssetEntityRepository extends EntityRepository<Asset> {
    public Integer getNextID() ;

    //
    List<Asset> findByAssetName(String name);
}
