package org.scrum.domain.services;

import org.scrum.domain.asset.Asset;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import java.util.List;

//@Repository
@EnableJpaRepositories
@RepositoryRestResource
public interface IAssetRaport extends JpaRepository<Asset, Integer>{
//                  	extends CrudRepository<Project, Integer>{
        // Queriable Named Operations
    @Query("SELECT a FROM Asset a WHERE a.assetName like %:assetName%")
    List<Asset> findByName(String assetName);

    @Query("SELECT a FROM Asset a WHERE a.assetID = :assetID")
    Asset findByAssetID(Integer assetID);

    @Query("SELECT a FROM Asset a WHERE a.assetName like %:aassetName%")
    List<Asset> findByAssetName(@Param("aassetName") String assetName);

    @Query("SELECT a FROM Asset a WHERE a.assetName LIKE :assetName OR a.assetID LIKE :aID")
    List<Asset> findByAssetNameOrAssetID(
            @Param("assetName") String assetName,
            @Param("aID") String aID);
}
