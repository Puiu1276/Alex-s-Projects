package org.scrum.domain.services;

import org.scrum.domain.asset.Asset;
import org.scrum.domain.location.Location;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface ILocationDomainService {

    public void setLocationEntityRepository(ILocationEntityRepository repository);
}
