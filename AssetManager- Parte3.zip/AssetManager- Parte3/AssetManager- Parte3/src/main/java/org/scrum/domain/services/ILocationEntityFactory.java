package org.scrum.domain.services;

import org.scrum.domain.location.Location;

public interface ILocationEntityFactory {
    public void setLocationEntityRepository(ILocationEntityRepository repository);

    public Location buildLocation(String adresaLocation);
    public ILocationEntityRepository getLocationEntityRepository();
}

