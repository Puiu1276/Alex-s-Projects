package org.scrum.domain.services;

import org.scrum.domain.location.Location;
import org.scrum.domain.repo.EntityRepository;

import java.util.List;

public interface ILocationEntityRepository extends EntityRepository<Location> {
    public Integer getNextID() ;
    List<Location> findByLocationAdress(String adress);
}
