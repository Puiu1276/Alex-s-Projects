package org.scrum.domain.services;

import org.scrum.domain.angajati.Angajat;
import org.scrum.domain.asset.Asset;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public interface IOperatiuneDomainService {
    public void setOperatiuneEntityRepository(IOperatiuneEntityRepository repository);
}
