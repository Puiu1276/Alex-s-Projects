package org.scrum.domain.services;

import org.scrum.domain.operatiune.Operatiune;

public interface IOperatiuneEntityFactory {
    public void setOperatiuneEntityRepository(IOperatiuneEntityRepository repository);

    public Operatiune buildOperatiune(String descriere);
    public IOperatiuneEntityRepository getOperatiuneEntityRepository();
}
