package org.scrum.domain.services;

import org.scrum.domain.operatiune.Operatiune;
import org.scrum.domain.repo.EntityRepository;

import java.util.Collection;
import java.util.List;

public interface IOperatiuneEntityRepository extends EntityRepository<Operatiune> {
    public Integer getNextID() ;

    //
    public Operatiune getById(Integer id);
    public Operatiune get(Operatiune sample);
    public Collection<Operatiune> toCollection(); // getAll

    //
    public Operatiune add(Operatiune entity);
    public Collection<Operatiune> addAll(Collection<Operatiune> entities);
    public boolean remove(Operatiune entity);
    public boolean removeAll(Collection<Operatiune> entities);

    //
    public int size();

    List<Operatiune> findByOperatiuneDescriere(String descriere);

}
