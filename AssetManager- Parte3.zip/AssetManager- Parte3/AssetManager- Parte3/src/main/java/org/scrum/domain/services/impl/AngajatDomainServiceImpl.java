package org.scrum.domain.services.impl;

import org.scrum.domain.services.IAngajatDomainService;
import org.scrum.domain.services.IAngajatEntityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class AngajatDomainServiceImpl implements IAngajatDomainService {
    @Autowired
    private IAngajatEntityRepository entityRepository;
    @Override
    public void setAngajatEntityRepository(IAngajatEntityRepository repository) {
        this.entityRepository = repository;
    }

    public AngajatDomainServiceImpl() {
        super();
    }
    public AngajatDomainServiceImpl(IAngajatEntityRepository entityRepository) {
        super();
        this.entityRepository = entityRepository;
    }
}
