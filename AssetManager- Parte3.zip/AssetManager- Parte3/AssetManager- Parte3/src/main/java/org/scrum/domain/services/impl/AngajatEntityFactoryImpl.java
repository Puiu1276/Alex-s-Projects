package org.scrum.domain.services.impl;

import jakarta.annotation.PostConstruct;
import org.scrum.domain.angajati.Angajat;
import org.scrum.domain.services.IAngajatEntityFactory;
import org.scrum.domain.services.IAngajatEntityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

@Component("DepartamentEntityFactoryBaseCDI")
@Scope("singleton") 	//@Scope(value = ConfigurableBeanFactory.SCOPE_SINGLETON)
public class AngajatEntityFactoryImpl implements IAngajatEntityFactory {
    private static Logger logger = Logger.getLogger(AngajatEntityFactoryImpl.class.getName());

    public AngajatEntityFactoryImpl() {
        logger.info(">>> BEAN: AngajatEntityFactoryImpl instantiated!");
    }
    @Autowired
    private IAngajatEntityRepository angajatEntityRepository;
    @Override
    public void setAngajatEntityRepository(IAngajatEntityRepository repository) {
        this.angajatEntityRepository = repository;
    }

    @Override
    public Angajat buildAngajat(String angajatName) {
        Integer nextID = this.angajatEntityRepository.getNextID();
        Angajat newAngajat = new Angajat(nextID, angajatName);

        Angajat angajat1 = new Angajat(this.angajatEntityRepository.getNextID(), "Marcel Ion");
        logger.info("NEW angajat "+newAngajat.getAngajatID()+")" + newAngajat.getAngajatName());
        this.angajatEntityRepository.add(angajat1);
        angajat1.setRole(Angajat.Role.ADMINISTRATOR);
        return newAngajat;
    }

    @Override
    public IAngajatEntityRepository getAngajatEntityRepository() {
        return angajatEntityRepository;
    }

    @PostConstruct
    private void initDomainServiceEntities() {
        logger.info(">> PostConstruct :: initDomainServiceEntities");
        Angajat angajat = buildAngajat("Marcel Ion");
        angajatEntityRepository.add(angajat);

        logger.info(">> EntityRepository angajat count :: " + angajatEntityRepository.size());
    }
}
