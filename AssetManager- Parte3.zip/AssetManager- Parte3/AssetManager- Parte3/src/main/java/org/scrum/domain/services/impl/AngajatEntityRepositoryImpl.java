package org.scrum.domain.services.impl;

import jakarta.persistence.*;
import org.scrum.domain.angajati.Angajat;
import org.scrum.domain.services.IAngajatEntityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.logging.Logger;

@Repository("DepartamentEntityRepositoryJPA")
@Transactional    //(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED)
public class AngajatEntityRepositoryImpl implements IAngajatEntityRepository {
    private static Logger logger = Logger.getLogger(AngajatEntityRepositoryImpl.class.getName());
    public AngajatEntityRepositoryImpl() {
        logger.info(">>> BEAN: AngajatEntityRepositoryImpl instantiated!");
    }

    @Autowired
    private EntityManager em;

    @Override
    public Angajat getById(Object id) {
        return em.find(Angajat.class, id);
    }

    @Override
    public boolean contains(Angajat entitySample) {
        Collection<Angajat> samples = getAll(entitySample);
        if (samples != null && samples.size() > 0)
            return true;
        return false;    }

    @Override
    public Collection<Angajat> getAll(Angajat entitySample) {
        List<Angajat> results = new ArrayList<>();

        if(entitySample.getAngajatID() != null)
            results.add(get(entitySample));

        // CriteriaBuilder could also be used instead of plain JPQL
        Map<String, Object> sqlCriterias = new HashMap<String, Object>();
        if(entitySample.getAngajatName() != null)
            sqlCriterias.put("name", entitySample.getAngajatName());

        String queryString = "SELECT a FROM Angajat a WHERE ";
        for (String criteria : sqlCriterias.keySet()) {
            if (sqlCriterias.get(criteria) instanceof Collection) {
                queryString += "o." + criteria + " IN (:" + criteria + ") AND ";
            } else {
                queryString += "o." + criteria + " = :" + criteria + " AND ";
            }
        }
        queryString += " 1 = 1";

        logger.info("JPAQL: " + queryString);

        Query query = em.createQuery(queryString, Angajat.class);
        for (String criteria : sqlCriterias.keySet()) {
            query = query.setParameter(criteria, sqlCriterias.get(criteria));
        }

        return query.getResultList();    }

    @Override
    public Angajat get(Angajat entitySample) {
        return getById(entitySample.getAngajatID());
    }

    @Override
    public Collection<Angajat> toCollection() {
        List<Angajat> angajatList = new ArrayList<>();
        angajatList.addAll(em.createQuery("SELECT a FROM Angajat a", Angajat.class).getResultList());
        return angajatList;    }

    @Override
    public Angajat[] toArray() {
        List<Angajat> angajati =  new ArrayList<>();
        angajati.addAll(this.toCollection());
        return angajati.toArray(new Angajat[1]);    }

    @Override
    public Angajat add(Angajat entity) {
        if (entity.getAngajatID() == null) {
            entity.setAngajatID(this.getNextID());
        }
        entity = em.merge(entity);
        return entity;    }

    @Override
    public Collection<Angajat> addAll(Collection<Angajat> entities) {
        for(Angajat entity: entities)
            this.add(entity);
        return entities;    }

    @Override
    public boolean remove(Angajat entity) {
        entity = this.getById(entity.getAngajatID());
        if(em.contains(entity)) {
            this.em.remove(entity);
            return true;
        }
        return false;    }

    @Override
    public boolean removeAll(Collection<Angajat> entities) {
        Boolean flag =  true;
        for(Angajat entity: entities) {
            if (!this.remove(entity))
                flag = false;
        }

        return flag;    }

    @Override
    public int size() {
        Long result = this.em.createQuery("SELECT COUNT(a) FROM Angajat a", Long.class).getSingleResult();
        return result.intValue();    }

    @Override
    public Angajat refresh(Angajat entity) {
        em.refresh(entity);
        return entity;    }

    @Override
    public Integer getNextID() {
        Angajat angajatWithNextId = new Angajat(null, "Angajat sample for next ID ...");

        em.persist(angajatWithNextId);
        em.flush();
        Integer nextID = angajatWithNextId.getAngajatID();
        em.refresh(angajatWithNextId);

        logger.info(">>>>>>>>>>>>>>> Generated ID: " + nextID);

        return nextID;    }

    @Override
    public List<Angajat> findByAngajatName(String name) {
        String queryString = "SELECT a FROM Angajat a WHERE a.name like %:aname%";
        Query query = em.createQuery(queryString, Angajat.class).setParameter("aname", name);
        return query.getResultList();    }

    @PrePersist
    public void onPrePersist(Angajat angajat) {
        auditAngajat(angajat, AngajatEntityOperation.ADDED);
    }

    @PreUpdate
    public void onPreUpdate(Angajat angajat) {
        auditAngajat(angajat, AngajatEntityOperation.UPDATED);
    }

    @PreRemove
    public void onPreRemove(Angajat angajat) {
        auditAngajat(angajat, AngajatEntityOperation.DELETED);
    }

    private void auditAngajat(Angajat angajat, AngajatEntityOperation operation) {
        logger.info(">>> AngajatEntityRepositoryJPA Listener: " + angajat + " > " + operation);
    }

    static public enum AngajatEntityOperation{
        ADDED, UPDATED, DELETED;
    }
}
