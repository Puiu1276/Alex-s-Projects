package org.scrum.domain.services.impl;

import org.scrum.domain.angajati.Angajat;
import org.scrum.domain.asset.Asset;
import org.scrum.domain.services.IAssetDomainService;
import org.scrum.domain.services.IAssetEntityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class AssetDomainServiceImpl implements IAssetDomainService {
    @Autowired
    private IAssetEntityRepository entityRepository;
    @Override
    public void setAssetEntityRepository(IAssetEntityRepository repository) {
        this.entityRepository = repository;
    }
    @Override
    public List<Angajat> getAngajatiAsset(Asset asset) {
        List<Angajat> angajatiAsset = new ArrayList<>();
        for (Angajat a : asset.getAngajat())
            angajatiAsset.add(a);
        return angajatiAsset;
    }

    @Override
    public Integer getAngajatiAssetCount(Asset asset) {
        List<Angajat> angajatiAsset = getAngajatiAsset(asset);
        return angajatiAsset.size();
    }

    @Override
    public List<Angajat> getAngajatiAsset(Integer assetID) {
        Asset asset = entityRepository.getById(assetID);
        return getAngajatiAsset(asset);
    }

    @Override
    public Integer getAngajatiAssetCount(Integer assetID) {
        Asset asset = entityRepository.getById(assetID);
        return getAngajatiAssetCount(assetID);
    }

    @Override
    public Angajat getAngajatAsset(Asset asset, String angajatName) {
        List<Angajat> angajatiAsset = getAngajatiAsset(asset);
        List<Angajat> angajati = angajatiAsset.stream().filter(f -> f.getAngajatName().equals(angajatName)).collect(Collectors.toList());
        if (angajati.size() > 0)
            return angajati.get(0);

        return null;
    }

    public AssetDomainServiceImpl(){
        super();
    }
    public AssetDomainServiceImpl(IAssetEntityRepository entityRepository) {
        super();
        this.entityRepository = entityRepository;
    }
}
