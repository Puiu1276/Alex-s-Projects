package org.scrum.domain.services.impl;

import jakarta.annotation.PostConstruct;
import org.scrum.domain.angajati.Angajat;
import org.scrum.domain.asset.Asset;
import org.scrum.domain.location.Location;
import org.scrum.domain.operatiune.Operatiune;
import org.scrum.domain.services.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.logging.Logger;

@Component("AngajatEntityFactoryBaseCDI")
@Scope("singleton") 	//@Scope(value = ConfigurableBeanFactory.SCOPE_SINGLETON)
public class AssetEntityFactoryImpl implements IAssetEntityFactory {
    private static Logger logger = Logger.getLogger(AssetEntityFactoryImpl.class.getName());

    public AssetEntityFactoryImpl() {
        logger.info(">>> BEAN: AssetEntityFactoryImpl instantiated!");
    }
    @Autowired
    private IAssetEntityRepository assetEntityRepository;
    @Autowired
    private IOperatiuneEntityRepository operatiuneEntityRepository;
    @Autowired
    private ILocationEntityRepository locationEntityRepository;
    @Override
    public void setAssetEntityRepository(IAssetEntityRepository repository) {
        this.assetEntityRepository = repository;
    }

    @Override
    public Asset buildAsset(String assetName) {
        Integer nextID = this.assetEntityRepository.getNextID();
        Asset newAsset= new Asset(nextID, assetName, Asset.AssetType.IMOBILIZARICORPORALE);

        Location location1 = new Location(this.locationEntityRepository.getNextID(),"Iulius Mall", "Romania", "Iasi", "Blvd. Metalurgiei nr. 9");
        newAsset.setCurrentLocation(location1);
        this.locationEntityRepository.add(location1);

        Operatiune newOperatiune = new Operatiune();
        newOperatiune.setAssetOperat(newAsset);
        newOperatiune.setLocatieCurenta(location1);
        newOperatiune.setDestinatieLocatie(new Location());

        operatiuneEntityRepository.add(newOperatiune);
        logger.info("NEW operatiune "+newOperatiune.toString());
        logger.info("NEW asset "+ newAsset.getAssetID()+")"+newAsset.getAssetName());
        newAsset.setAssetType(Asset.AssetType.IMOBILIZARICORPORALE);
        return newAsset;
    }

    public void changeAssetLocation(Integer locationID, Integer assetID)
    {
        Location location = new Location(1,"Copou", "Romania", "Iasi", "Blvd. Carol I, nr. 9");
        locationEntityRepository.add(location);
        Asset asset = this.assetEntityRepository.getById(assetID);
        asset.setDestinatieLocatie(location);

        Operatiune newOperatiune = new Operatiune();
        newOperatiune.setAssetOperat(asset);
        newOperatiune.setDestinatieLocatie(location);
        newOperatiune.setTipOpeariune(Operatiune.OperatiuneTip.TRANSFER);
        logger.info("NEW operatiune "+ newOperatiune.toString());
    }

    @Override
    public IAssetEntityRepository getAssetEntityRepository() {
        return assetEntityRepository;
    }

    @PostConstruct
    private void initDomainServiceEntities() {
        logger.info(">> PostConstruct :: initDomainServiceEntities");
        Asset asset = buildAsset("Imprimanta color Brother");
        assetEntityRepository.add(asset);
        changeAssetLocation(assetEntityRepository.get(asset).getAssetID(),1);


        logger.info(">> EntityRepository asset count :: " + assetEntityRepository.size());
    }
}
