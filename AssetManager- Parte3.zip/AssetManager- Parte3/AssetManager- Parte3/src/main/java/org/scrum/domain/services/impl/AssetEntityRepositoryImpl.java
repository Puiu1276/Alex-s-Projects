package org.scrum.domain.services.impl;

import jakarta.persistence.*;
import org.scrum.domain.asset.Asset;
import org.scrum.domain.services.IAssetEntityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.logging.Logger;

@Repository("AssetEntityRepositoryJPA")
@Transactional    //@Scope(value = ConfigurableBeanFactory.SCOPE_SINGLETON)
public class AssetEntityRepositoryImpl implements IAssetEntityRepository {
    private static Logger logger = Logger.getLogger(AssetEntityRepositoryImpl.class.getName());
    public AssetEntityRepositoryImpl() {
        logger.info(">>> BEAN: AssetEntityRepositoryImpl instantiated!");
    }

    @Autowired
    private EntityManager em;
    @Override
    public Asset getById(Object id) {
        return em.find(Asset.class, id);
    }

    @Override
    public boolean contains(Asset entitySample) {
        Collection<Asset> samples = getAll(entitySample);
        if (samples != null && samples.size() > 0)
            return true;
        return false;
    }

    @Override
    public Collection<Asset> getAll(Asset entitySample) {
        List<Asset> results = new ArrayList<>();

        if(entitySample.getAssetID() != null)
            results.add(get(entitySample));

        // CriteriaBuilder could also be used instead of plain JPQL
        Map<String, Object> sqlCriterias = new HashMap<String, Object>();
        if(entitySample.getAssetName() != null)
            sqlCriterias.put("name", entitySample.getAssetName());
        //
        String queryString = "SELECT a FROM Asset a WHERE ";
        for (String criteria : sqlCriterias.keySet()) {
            if (sqlCriterias.get(criteria) instanceof Collection) {
                queryString += "o." + criteria + " IN (:" + criteria + ") AND ";
            } else {
                queryString += "o." + criteria + " = :" + criteria + " AND ";
            }
        }
        queryString += " 1 = 1";

        logger.info("JPAQL: " + queryString);

        Query query = em.createQuery(queryString, Asset.class);
        for (String criteria : sqlCriterias.keySet()) {
            query = query.setParameter(criteria, sqlCriterias.get(criteria));
        }

        return query.getResultList();
    }

    @Override
    public Asset get(Asset entitySample) {
        return getById(entitySample.getAssetID());
    }

    @Override
    public Collection<Asset> toCollection() {
        List<Asset> assetList = new ArrayList<>();
        assetList.addAll(em.createQuery("SELECT a FROM Asset a", Asset.class).getResultList());
        return assetList;
    }

    @Override
    public Asset[] toArray() {
        List<Asset> assets =  new ArrayList<>();
        assets.addAll(this.toCollection());
        return assets.toArray(new Asset[1]);
    }

    @Override
    public Asset add(Asset entity) {
        if (entity.getAssetID() == null) {
            entity.setAssetID(this.getNextID());
        }
        entity = em.merge(entity);
        return entity;
    }

    @Override
    public Collection<Asset> addAll(Collection<Asset> entities) {
        for(Asset entity: entities)
            this.add(entity);
        return entities;
    }

    @Override
    public boolean remove(Asset entity) {
        entity = this.getById(entity.getAssetID());
        if(em.contains(entity)) {
            this.em.remove(entity);
            return true;
        }
        return false;
    }

    @Override
    public boolean removeAll(Collection<Asset> entities) {
        Boolean flag =  true;
        for(Asset entity: entities) {
            if (!this.remove(entity))
                flag = false;
        }

        return flag;
    }

    @Override
    public int size() {
        Long result = this.em.createQuery("SELECT COUNT(a) FROM Asset a", Long.class).getSingleResult();
        return result.intValue();
    }

    @Override
    public Asset refresh(Asset entity) {
        em.refresh(entity);
        return entity;
    }

    @Override
    public Integer getNextID() {
        Asset assetWithNextId = new Asset(null, "Asset sample for next ID ...", Asset.AssetType.IMOBILIZARICORPORALE);

        em.persist(assetWithNextId);
        em.flush();
        Integer nextID = assetWithNextId.getAssetID();
        em.refresh(assetWithNextId);

        logger.info(">>>>>>>>>>>>>>> Generated ID: " + nextID);

        return nextID;
    }

    @Override
    public List<Asset> findByAssetName(String name) {
        String queryString = "SELECT a FROM Asset a WHERE a.name like %:aname%";
        Query query = em.createQuery(queryString, Asset.class).setParameter("aname", name);
        return query.getResultList();    }

    @PrePersist
    public void onPrePersist(Asset asset) {
        auditAsset(asset, AssetEntityOperation.ADDED);
    }

    @PreUpdate
    public void onPreUpdate(Asset asset) {
        auditAsset(asset, AssetEntityOperation.UPDATED);
    }

    @PreRemove
    public void onPreRemove(Asset asset) {
        auditAsset(asset, AssetEntityOperation.DELETED);
    }

    private void auditAsset(Asset asset, AssetEntityOperation operation) {
        logger.info(">>> AssetEntityRepositoryJPA Listener: " + asset + " > " + operation);

    }

    static public enum AssetEntityOperation{
        ADDED, UPDATED, DELETED;
    }
}
