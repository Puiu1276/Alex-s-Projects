package org.scrum.domain.services.impl;

import org.scrum.domain.asset.Asset;
import org.scrum.domain.location.Location;
import org.scrum.domain.services.ILocationDomainService;
import org.scrum.domain.services.ILocationEntityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LocationDomainServiceImpl implements ILocationDomainService {
    @Autowired
    private ILocationEntityRepository entityRepository;

    @Override
    public void setLocationEntityRepository(ILocationEntityRepository repository) {
        this.entityRepository = repository;
    }

    public LocationDomainServiceImpl() {
        super();
    }

    public LocationDomainServiceImpl(ILocationEntityRepository entityRepository) {
        super();
        this.entityRepository = entityRepository;
    }
}
