package org.scrum.domain.services.impl;


import jakarta.annotation.PostConstruct;
import org.scrum.domain.location.Location;
import org.scrum.domain.services.ILocationEntityFactory;
import org.scrum.domain.services.ILocationEntityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.logging.Logger;

@Component("EvaluareEntityFactoryBaseCDI")
@Scope("singleton") 	//@Scope(value = ConfigurableBeanFactory.SCOPE_SINGLETON)
public class LocationEntityFactoryImpl implements ILocationEntityFactory {
    private static Logger logger = Logger.getLogger(LocationEntityFactoryImpl.class.getName());

    public LocationEntityFactoryImpl() {
        logger.info(">>> BEAN: LocationEntityFactoryImpl instantiated!");
    }
    @Autowired
    private ILocationEntityRepository entityRepository;

    @Override
    public void setLocationEntityRepository(ILocationEntityRepository repository) {
        this.entityRepository = repository;
    }

    @Override
    public Location buildLocation(String adresaLocation) {
        Integer nextID = this.entityRepository.getNextID();

        Location newLocation = new Location(nextID, adresaLocation, "", "", "");


        newLocation.setDestinatieLocatie(new Location());


        logger.info("NEW location " + newLocation.getLocationName());
        return newLocation;
    }

    @Override
    public ILocationEntityRepository getLocationEntityRepository() {
        return entityRepository;
    }

    public LocationEntityFactoryImpl(ILocationEntityRepository entityRepository) {
        super();
        this.entityRepository = entityRepository;
    }

    @PostConstruct
    private void initDomainServiceEntities() {
        logger.info(">> PostConstruct :: initDomainServiceEntities");
        entityRepository.add(buildLocation("Blvd. Carol I nr. 9"));


        logger.info(">> EntityRepository location count :: " + entityRepository.size());
    }
}
