package org.scrum.domain.services.impl;

import jakarta.persistence.*;
import org.scrum.domain.location.Location;
import org.scrum.domain.services.ILocationEntityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.logging.Logger;

@Repository("EvaluareEntityRepositoryJPA")
@Transactional    //(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED)
public class LocationEntityRepositoryImpl implements ILocationEntityRepository {
    private static Logger logger = Logger.getLogger(LocationEntityRepositoryImpl.class.getName());

    public LocationEntityRepositoryImpl() {
        logger.info(">>> BEAN: LocationEntityRepositoryImpl instantiated!");
    }

    @Autowired
    private EntityManager em;

    @Override
    public Location getById(Object id) {
        return em.find(Location.class, id);
    }

    @Override
    public boolean contains(Location entitySample) {
        Collection<Location> samples = getAll(entitySample);
        if (samples != null && samples.size() > 0)
            return true;
        return false;    }

    @Override
    public Collection<Location> getAll(Location entitySample) {
        List<Location> results = new ArrayList<>();

        if (entitySample.getLocationID() != null)
            results.add(get(entitySample));

        // CriteriaBuilder could also be used instead of plain JPQL
        Map<String, Object> sqlCriterias = new HashMap<String, Object>();
        if (entitySample.getLocationName() != null)
            sqlCriterias.put("name", entitySample.getLocationName());

        String queryString = "SELECT l FROM Location l WHERE ";
        for (String criteria : sqlCriterias.keySet()) {
            if (sqlCriterias.get(criteria) instanceof Collection) {
                queryString += "o." + criteria + " IN (:" + criteria + ") AND ";
            } else {
                queryString += "o." + criteria + " = :" + criteria + " AND ";
            }
        }
        queryString += " 1 = 1";

        logger.info("JPAQL: " + queryString);

        Query query = em.createQuery(queryString, Location.class);
        for (String criteria : sqlCriterias.keySet()) {
            query = query.setParameter(criteria, sqlCriterias.get(criteria));
        }

        return query.getResultList();
    }

    @Override
    public Location get(Location entitySample) {
        return getById(entitySample.getLocationID());
    }

    @Override
    public Collection<Location> toCollection() {
        List<Location> locationList = new ArrayList<>();
        locationList.addAll(em.createQuery("SELECT l FROM Location l", Location.class).getResultList());
        return locationList;
    }

    @Override
    public Location[] toArray() {
        List<Location> locationList =  new ArrayList<>();
        locationList.addAll(this.toCollection());
        return locationList.toArray(new Location[1]);    }

    @Override
    public Location add(Location entity) {
        if (entity.getLocationID() == null) {
            entity.setLocationID(this.getNextID());
        }
        entity = em.merge(entity);
        return entity;
    }

    @Override
    public Collection<Location> addAll(Collection<Location> entities) {
        for(Location entity: entities)
            this.add(entity);
        return entities;
    }

    @Override
    public boolean remove(Location entity) {
        entity = this.getById(entity.getLocationID());
        if(em.contains(entity)) {
            this.em.remove(entity);
            return true;
        }
        return false;    }

    @Override
    public boolean removeAll(Collection<Location> entities) {
        Boolean flag =  true;
        for(Location entity: entities) {
            if (!this.remove(entity))
                flag = false;
        }

        return flag;
    }

    @Override
    public int size() {
        Long result = this.em.createQuery("SELECT COUNT(l) FROM Location l", Long.class).getSingleResult();
        return result.intValue();
    }

    @Override
    public Location refresh(Location entity) {
        em.refresh(entity);
        return entity;
    }

    @Override
    public Integer getNextID() {
        Location locationWithNextId = new Location(null, "Location test ...", "", "", "");

        em.persist(locationWithNextId);
        em.flush();
        Integer nextID = locationWithNextId.getLocationID();
        em.refresh(locationWithNextId);

        logger.info(">>>>>>>>>>>>>>> Generated ID: " + nextID);

        return nextID;
    }

    @PrePersist
    public void onPrePersist(Location location) {
        auditLocation(location, LocationEntityRepositoryImpl.LocationEntityOperation.ADDED);
    }

    @PreUpdate
    public void onPreUpdate(Location location) {
        auditLocation(location, LocationEntityRepositoryImpl.LocationEntityOperation.UPDATED);
    }

    @PreRemove
    public void onPreRemove(Location location) {
        auditLocation(location, LocationEntityRepositoryImpl.LocationEntityOperation.DELETED);
    }

    private void auditLocation(Location location, LocationEntityRepositoryImpl.LocationEntityOperation operation) {
        logger.info(">>> LocationEntityRepositoryJPA Listener: " + location + " > " + operation);

    }

    @Override
    public List<Location> findByLocationAdress(String adress) {
        String queryString = "SELECT l FROM Location l WHERE l.adressLocation like %:ladress%";
        Query query = em.createQuery(queryString, Location.class).setParameter("ladress", adress);
        return query.getResultList();
    }

    static public enum LocationEntityOperation{
        ADDED, UPDATED, DELETED;
    }
}
