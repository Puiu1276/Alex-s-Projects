package org.scrum.domain.services.impl;

import org.scrum.domain.services.IOperatiuneDomainService;
import org.scrum.domain.services.IOperatiuneEntityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class OperatiuneDomainServiceImpl implements IOperatiuneDomainService {
    @Autowired
    private IOperatiuneEntityRepository entityRepository;
    @Override
    public void setOperatiuneEntityRepository(IOperatiuneEntityRepository repository) {
        this.entityRepository = repository;
    }

    public OperatiuneDomainServiceImpl() {
        super();
    }
    public OperatiuneDomainServiceImpl(IOperatiuneEntityRepository entityRepository) {
        super();
        this.entityRepository = entityRepository;
    }
}
