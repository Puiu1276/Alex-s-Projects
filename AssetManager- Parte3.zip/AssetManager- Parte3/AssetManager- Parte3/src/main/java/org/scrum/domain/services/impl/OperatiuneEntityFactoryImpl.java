package org.scrum.domain.services.impl;

import jakarta.annotation.PostConstruct;
import org.scrum.domain.operatiune.Operatiune;
import org.scrum.domain.services.IOperatiuneEntityFactory;
import org.scrum.domain.services.IOperatiuneEntityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.logging.Logger;

@Component("OperatiuneEntityFactoryBaseCDI")
@Scope("singleton")
public class OperatiuneEntityFactoryImpl implements IOperatiuneEntityFactory {
    private static Logger logger = Logger.getLogger(OperatiuneEntityFactoryImpl.class.getName());

    public OperatiuneEntityFactoryImpl() {
        logger.info(">>> BEAN: OperatiuneEntityFactoryImpl instantiated!");
    }
    @Autowired
    private IOperatiuneEntityRepository entityRepository;

    @Autowired
    private IOperatiuneEntityRepository operatiuneEntityRepository;

    @Override
    public void setOperatiuneEntityRepository(IOperatiuneEntityRepository repository) {
        this.entityRepository = repository;
    }

    @Override
    public Operatiune buildOperatiune(String descriere) {
        Integer nextID2 = this.operatiuneEntityRepository.getNextID();

        Operatiune newOperatiune = new Operatiune(nextID2, "Operatiune de Transfer", Operatiune.OperatiuneTip.TRANSFER);

        newOperatiune.setDescriereOperatiune(descriere);
        logger.info("NEW Operatiune " + newOperatiune.getOperatiuneID()+")"+newOperatiune.getDescriereOperatiune());
        return newOperatiune;
    }

    @Override
    public IOperatiuneEntityRepository getOperatiuneEntityRepository() {
        return entityRepository;
    }

    @PostConstruct
    private void initDomainServiceEntities() {
        logger.info(">> PostConstruct :: initDomainServiceEntities");
        entityRepository.add(buildOperatiune("Operatiune de Transfer"));


        logger.info(">> EntityRepository operatiune count :: " + entityRepository.size());
    }
}
