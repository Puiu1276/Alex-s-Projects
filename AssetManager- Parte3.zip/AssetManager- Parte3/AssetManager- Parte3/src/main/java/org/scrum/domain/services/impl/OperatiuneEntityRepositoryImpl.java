package org.scrum.domain.services.impl;

import jakarta.persistence.*;
import org.scrum.domain.operatiune.Operatiune;
import org.scrum.domain.services.IOperatiuneEntityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.logging.Logger;

@Repository("OperatiuneEntityRepositoryJPA")
@Transactional    //(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED)
public class OperatiuneEntityRepositoryImpl implements IOperatiuneEntityRepository {
    private static Logger logger = Logger.getLogger(OperatiuneEntityRepositoryImpl.class.getName());
    public OperatiuneEntityRepositoryImpl() {
        logger.info(">>> BEAN: AngajatEntityRepositoryImpl instantiated!");
    }

    @Autowired
    private EntityManager em;

    @Override
    public Operatiune getById(Object id) {
        return em.find(Operatiune.class, id);
    }

    @Override
    public boolean contains(Operatiune entitySample){
            Collection<Operatiune> samples = getAll(entitySample);
            if (samples != null && samples.size() > 0)
                return true;
            return false;    }

    @Override
    public Collection<Operatiune> getAll(Operatiune entitySample) {
        List<Operatiune> results = new ArrayList<>();

        if(entitySample.getOperatiuneID() != null)
            results.add(get(entitySample));

        // CriteriaBuilder could also be used instead of plain JPQL
        Map<String, Object> sqlCriterias = new HashMap<String, Object>();
        if(entitySample.getDescriereOperatiune() != null)
            sqlCriterias.put("name", entitySample.getDescriereOperatiune());

        String queryString = "SELECT op FROM Operatiune op WHERE ";
        for (String criteria : sqlCriterias.keySet()) {
            if (sqlCriterias.get(criteria) instanceof Collection) {
                queryString += "o." + criteria + " IN (:" + criteria + ") AND ";
            } else {
                queryString += "o." + criteria + " = :" + criteria + " AND ";
            }
        }
        queryString += " 1 = 1";

        logger.info("JPAQL: " + queryString);

        Query query = em.createQuery(queryString, Operatiune.class);
        for (String criteria : sqlCriterias.keySet()) {
            query = query.setParameter(criteria, sqlCriterias.get(criteria));
        }

        return query.getResultList();    }

    @Override
    public Operatiune[] toArray() {
        List<Operatiune> operatiunes =  new ArrayList<>();
        operatiunes.addAll(this.toCollection());
        return operatiunes.toArray(new Operatiune[1]);    }

    @Override
    public Operatiune refresh(Operatiune entity) {
        em.refresh(entity);
        return entity;    }

    @Override
    public Integer getNextID() {
        Operatiune operatiuneWithNextId = new Operatiune(null, "Operatiune tip Transfer.", Operatiune.OperatiuneTip.TRANSFER);

        em.persist(operatiuneWithNextId);
        em.flush();
        Integer nextID = operatiuneWithNextId.getOperatiuneID();
        em.refresh(operatiuneWithNextId);

        logger.info(">>>>>>>>>>>>>>> Generated ID: " + nextID);

        return nextID;    }

    @Override
    public Operatiune getById(Integer id) {
        return null;
    }

    @Override
    public Operatiune get(Operatiune sample) {
        return getById(sample.getOperatiuneID());
    }

    @Override
    public Collection<Operatiune> toCollection() {
        List<Operatiune> operatiuneList = new ArrayList<>();
        operatiuneList.addAll(em.createQuery("SELECT op FROM Operatiune op", Operatiune.class).getResultList());
        return operatiuneList;    }

    @Override
    public Operatiune add(Operatiune entity) {
        if (entity.getOperatiuneID() == null) {
            entity.setOperatiuneID(this.getNextID());
        }
        entity = em.merge(entity);
        return entity;    }

    @Override
    public Collection<Operatiune> addAll(Collection<Operatiune> entities) {
        for(Operatiune entity: entities)
            this.add(entity);
        return entities;    }

    @Override
    public boolean remove(Operatiune entity) {
        entity = this.getById(entity.getOperatiuneID());
        if(em.contains(entity)) {
            this.em.remove(entity);
            return true;
        }
        return false;    }

    @Override
    public boolean removeAll(Collection<Operatiune> entities) {
        Boolean flag =  true;
        for(Operatiune entity: entities) {
            if (!this.remove(entity))
                flag = false;
        }

        return flag;    }

    @Override
    public int size() {
        Long result = this.em.createQuery("SELECT COUNT(op) FROM Operatiune op", Long.class).getSingleResult();
        return result.intValue();    }

    @Override
    public List<Operatiune> findByOperatiuneDescriere(String descriere) {
        String queryString = "SELECT op FROM Operatiune op WHERE op.descriere like %:opdescriere%";
        Query query = em.createQuery(queryString, Operatiune.class).setParameter("opdescriere", descriere);
        return query.getResultList();
    }

    @PrePersist
    public void onPrePersist(Operatiune operatiune) {
        auditOperatiune(operatiune, OperatiuneEntityRepositoryImpl.OperatiuneEntityOperation.ADDED);
    }

    @PreUpdate
    public void onPreUpdate(Operatiune operatiune) {
        auditOperatiune(operatiune, OperatiuneEntityRepositoryImpl.OperatiuneEntityOperation.UPDATED);
    }

    @PreRemove
    public void onPreRemove(Operatiune operatiune) {
        auditOperatiune(operatiune, OperatiuneEntityRepositoryImpl.OperatiuneEntityOperation.DELETED);
    }

    private void auditOperatiune(Operatiune evaluationCriteria, OperatiuneEntityRepositoryImpl.OperatiuneEntityOperation operation) {
        logger.info(">>> OperatiuneEntityRepositoryJPA Listener: " + evaluationCriteria + " > " + operation);

    }

    static public enum OperatiuneEntityOperation{
        ADDED, UPDATED, DELETED;
    }
}
