package org.scrum.domain.services;


import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.scrum.domain.asset.Asset;
import org.scrum.domain.httpApp.AssetDTO;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

import java.nio.charset.Charset;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import static org.junit.Assert.assertTrue;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class Test_AssetAppServiceREST {

    private static Logger logger = Logger.getLogger(Test_AssetAppServiceREST.class.getName());

    private static String serviceURL = "http://localhost:8088/scrum/rest/service/assets";
    //
    private RestTemplate restTemplate = new RestTemplate();
    //@Autowired private TestRestTemplate restTemplate;

    @Test
    @Order(1)
    public void test1_GetCollectionResource() throws Exception {
        logger.info("DEBUG: Junit Spring REST Template TESTING: test_GetResource ...");
        HttpHeaders headers = generateHeaders();

        String stringResponse = restTemplate.exchange(
                serviceURL,
                HttpMethod.GET,
                new HttpEntity<>(headers),
                String.class
        ).getBody();

        logger.info("DEBUG: Junit TESTING Spring REST Template: GetMessage ... " + stringResponse);

    }

    @Test @Order(2)
    public void test2_DeleteAsset() throws Exception {
        logger.info("DEBUG: Junit Spring REST Template TESTING: test2_DeleteProject ...");
        HttpHeaders headers = generateHeaders();

        List<AssetDTO> assets = restTemplate.exchange(
                serviceURL,
                HttpMethod.GET,
                new HttpEntity<>(headers),
                new ParameterizedTypeReference<List<AssetDTO>>() {}
        ).getBody();

        assets.forEach(p -> System.out.println("Project before delete: " + p));

        // delete requests
        for (AssetDTO a: assets) {
            logger.info(">>> TO DELETE: " + serviceURL + "/" + a.getAssetID());
            this.restTemplate.exchange(
                    serviceURL + "/" + a.getAssetID(),
                    HttpMethod.DELETE,
                    new HttpEntity<>(headers),
                    new ParameterizedTypeReference<List<AssetDTO>>() {}
            ).getBody();
        }

        //
        assets = restTemplate.exchange(
                serviceURL,
                HttpMethod.GET,
                new HttpEntity<>(headers),
                new ParameterizedTypeReference<List<AssetDTO>>() {}
        ).getBody();

        assertTrue("Fail to delete Projects!", assets.isEmpty());
    }

    @Test @Order(3)
    public void test3_AddAsset() throws Exception {
        // addIntoCollection
        logger.info("DEBUG: Junit TESTING Spring REST Template: test3_AddProject ...");

        Integer assetsToAdd = 3;
        AssetDTO asset;
        String resourceString;

        for (int i=1; i <= assetsToAdd; i++){
            asset = new AssetDTO(i, "Asset_Stoc", Asset.AssetType.STOCURI);
            asset.setAssetName("Asset1");
            //
            HttpHeaders headers = generateHeaders();
            //
            resourceString = this.restTemplate.exchange(
                    serviceURL,
                    HttpMethod.POST,
                    new HttpEntity<>(asset, headers),
                    String.class
            ).getBody();
            logger.info("++++ " + "NEW Resource-Project: " + resourceString);
        }
    }

    @Test @Order(4)
    public void test4_UpdateAsset() throws Exception {
        logger.info("DEBUG: Junit Spring REST Template TESTING: test4_UpdateProject ...");
        HttpHeaders headers = generateHeaders();

        List<AssetDTO> projects = restTemplate.exchange(
                serviceURL,
                HttpMethod.GET,
                new HttpEntity<>(headers),
                new ParameterizedTypeReference<List<AssetDTO>>() {}
        ).getBody();

        projects.forEach(p -> System.out.println("Project before update: " + p));

        // update requests
        String resourceString;
        for (AssetDTO a: projects) {
            logger.info(">>> TO UPDATE: " + serviceURL + "/" + a.getAssetID());
            a.setAssetName(a.getAssetName() + ".UPDATED");
            //
//            for(AssetDTO r: a.get())
//                r.setCodeName(r.getCodeName() + ".U");
            //
            resourceString = this.restTemplate.exchange(
                    serviceURL + "/" + a.getAssetID(),
                    HttpMethod.PUT,
                    new HttpEntity<>(a, headers),
                    String.class
            ).getBody();
            logger.info("#### " + "UPDATED Resource-Project: " + resourceString);
        }
    }


    @Test @Order(5)
    public void test5_GetAssets() throws Exception {
        logger.info("DEBUG: Junit Spring REST Template TESTING: test5_Getprojects ...");
        HttpHeaders headers = generateHeaders();

        List<AssetDTO> projectsResource = restTemplate.exchange(
                serviceURL,
                HttpMethod.GET,
                new HttpEntity<>(headers),
                new ParameterizedTypeReference<List<AssetDTO>>() {}
        ).getBody();

        projectsResource.forEach(p -> System.out.println("projects: " + p));
    }

    // Utility method for security
    private String createAuthHeader(String username, String password) {
        String auth = username + ":" + password;

        byte[] encodedAuth = Base64.getEncoder().encode(
                auth.getBytes(Charset.forName("US-ASCII")) );

        String authHeader = "Basic " + new String( encodedAuth );

        return authHeader;
    }

    private HttpHeaders generateHeaders() {
        HttpHeaders headers = new HttpHeaders();
        //headers.add("Authorization", createAuthHeader("developer", "msd"));
        headers.add(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
        headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
        return headers;
    }
}
