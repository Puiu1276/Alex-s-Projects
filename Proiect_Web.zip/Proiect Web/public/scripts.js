// Get the input, search button, and results elements from the DOM
const searchBar = document.getElementById("search-bar");
const searchButton = document.getElementById("search-button");
const results = document.getElementById("results");

const addProductForm = document.getElementById("add-product-form");
addProductForm.hidden = true;

// Handle the search button click event
searchButton.addEventListener("click", () => {
  const searchTerm = searchBar.value.trim().toLowerCase();
  results.innerHTML = ""; // Clear the results container

  if (searchTerm === "") {
    return; // Do not search if the input is empty
  }

  // Fetch and filter the products based on the search term
  // Fetch and find the product that matches the search term exactly
  fetch("/getProducts")
    .then((response) => {
      if (!response.ok) {
        throw new Error("Network response was not ok");
      }
      return response.json();
    })
    .then((data) => {
      const products = data.products;
      const matchedProduct = products.find((product) => {
        return product.name.toLowerCase() === searchTerm;
      });

      // Display the matched product
      if (matchedProduct) {
        const productInfo = document.createElement("p");
        productInfo.classList.add("product-info");
      
        const name = document.createElement("div");
        name.textContent = `Name: ${matchedProduct.name}`;
        productInfo.appendChild(name);
      
        const price = document.createElement("div");
        price.textContent = `Price: ${matchedProduct.price}`;
        productInfo.appendChild(price);
      
        const quantity = document.createElement("div");
        quantity.textContent = `Quantity: ${matchedProduct.quantity}`;
        productInfo.appendChild(quantity);
      
        results.appendChild(productInfo);
        addProductForm.hidden = true;
      } else {
        const noMatchMessage = document.createElement("p");
        noMatchMessage.textContent = "No product matches your search term.";
        noMatchMessage.classList.add("result-text");
        results.appendChild(noMatchMessage);
        
        const addNewProductButton = document.createElement("button");
        addNewProductButton.textContent = "Add new product";
        addNewProductButton.classList.add("add-button");
        results.appendChild(addNewProductButton);

        addNewProductButton.addEventListener("click", () => {
          addProductForm.hidden = false;
        })
      }
    })
    .catch((error) => {
      console.error("There was a problem with the fetch operation:", error);
    });
});

addProductForm.addEventListener("submit", (event) => {
  event.preventDefault(); // Prevent the default form submission

  const name = searchBar.value.trim();
  const price = parseFloat(document.getElementById("price").value);
  const quantity = parseInt(document.getElementById("quantity").value);

  const newProduct = {
    name: name,
    price: price,
    quantity: quantity,
  };

  // Send the new product to the server
  fetch("/addProduct", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(newProduct),
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error("Network response was not ok");
      }
      return response.text();
    })
    .then((message) => {
      console.log(message);
      addProductForm.reset(); // Reset the form
      addProductForm.hidden = true;
      results.innerHTML = ""; // Clear the results container
    })
    .catch((error) => {
      console.error("There was a problem with the fetch operation:", error);
    });
});
