const express = require("express");
const fs = require("fs");
const path = require("path");
const app = express();
const port = 3000;

// Serve static files from the 'public' folder
app.use(express.static("public"));

app.use(express.json()); // To parse JSON data in the request body

// Add a new route to handle getting the products
app.get("/getProducts", (req, res) => {
  fs.readFile(
    path.join(__dirname, "public", "products.json"),
    "utf8",
    (err, jsonString) => {
      if (err) {
        console.error("Error reading the file:", err);
        res.status(500).send("Error reading the file");
        return;
      }

      try {
        const data = JSON.parse(jsonString);
        res.status(200).json(data);
      } catch (error) {
        console.error("Error parsing JSON:", error);
        res.status(500).send("Error parsing JSON");
      }
    }
  );
});

// Add a new route to handle adding a new product
app.post("/addProduct", (req, res) => {
  const newProduct = req.body;

  fs.readFile(
    path.join(__dirname, "public", "products.json"),
    "utf8",
    (err, jsonString) => {
      if (err) {
        console.error("Error reading the file:", err);
        res.status(500).send("Error reading the file");
        return;
      }

      try {
        const data = JSON.parse(jsonString);
        data.products.push(newProduct);

        fs.writeFile(
          path.join(__dirname, "public", "products.json"),
          JSON.stringify(data),
          (err) => {
            if (err) {
              console.error("Error writing the file:", err);
              res.status(500).send("Error writing the file");
              return;
            }
            res.status(200).send("Product added successfully");
          }
        );
      } catch (error) {
        console.error("Error parsing JSON:", error);
        res.status(500).send("Error parsing JSON");
      }
    }
  );
});

app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});
