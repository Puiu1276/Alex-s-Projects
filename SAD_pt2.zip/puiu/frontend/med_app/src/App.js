import './App.css';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from './pages/Home';
import Afectiuni from './pages/Afectiuni';
import Vaccinare from './pages/Vaccinare';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/">
          <Route index element={<Home />} />
          <Route path="afectiuni" element={<Afectiuni />} />
          <Route path="vaccinare" element={<Vaccinare />} />
          <Route path="venituri" element={<Afectiuni />} />
          <Route path="fidelizare" element={<Afectiuni />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
