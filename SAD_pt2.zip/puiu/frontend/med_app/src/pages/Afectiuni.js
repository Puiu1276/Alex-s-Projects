import { useState } from 'react';
import '../App.css';
import { Chart } from './Chart';
import SearchBar from './SearchBar';
import SelectBox from './SelectBox';
import SelectBox2 from './SelectBox2';
import UserService from '../services/user.services';

function Afectiuni() {
  const [season, setSeason] = useState('');
  const [species, setSpecies] = useState('');
  const [breed, setBreed] = useState('');
  const [dataArray, setData] = useState([]);
  const [labelsArray, setLabels] = useState([]);
  const [opts, setOpts] = useState({});

  const handleSeasonChange = (newSeason) => {
    setSeason(newSeason);
  };
  const handleSpeciesChange = (newSpecies) => {
    setSpecies(newSpecies);
  };
  const handleBreedChange = (newBreed) => {
    setBreed(newBreed);
  };

  const searchChart = (event) => {
    event.preventDefault();
    UserService.getConditions(season, breed, species).then(
        (response) => {
          setData(response.data.nr_cazuri);
          setLabels(response.data.denumiri);
          setOpts(response.data.opts);
        },
        (error) => {
          const resMessage =
            (error.response &&
              error.response.data &&
              error.response.data.message) ||
            error.message ||
            error.toString();
            console.log(resMessage);
        }
      );
  }

  const exportXlsx = (event) => {
    event.preventDefault();
    UserService.getXlsx(opts).then(
        (response) => {
      if (response.data) {
        if (opts != {} && opts != null && opts != undefined && opts.data != undefined) {
          const blob = new Blob([response.data], { type: 'application/zip' });
          const url = window.URL.createObjectURL(blob);
          const link = document.createElement('a');
          link.href = url;
          link.setAttribute('download', 'afectiuni.zip');
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
        }
      } else {
        console.error('Răspuns invalid de la server');
      }
        },
        (error) => {
          const resMessage =
            (error.response &&
              error.response.data &&
              error.response.data.message) ||
            error.message ||
            error.toString();
            console.log(resMessage);
        }
      );
  }

  return (
    <div className="page-afectiuni">
      <div className="header">VET APP</div>
      <div className='afectiuni'>
        <div className='afectiuni-1'>
            <SelectBox  season={season} onSeasonChange={handleSeasonChange} ></SelectBox>
            <SelectBox2  species={species} onSpeciesChange={handleSpeciesChange} ></SelectBox2>
            <SearchBar species={species} onBreedChange={handleBreedChange} ></SearchBar>
            <div className="bn39 bn10" onClick={searchChart}><span className="bn39span">Cauta</span></div>
            <div className="bn39 bn10" onClick={exportXlsx}><span className="bn39span">Export excel</span></div>
        </div>
        <div className='afectiuni-2'>
            <Chart dataArray={dataArray} labelsArray={labelsArray}></Chart>
        </div>
      </div>
    </div>
  );
}

export default Afectiuni;
