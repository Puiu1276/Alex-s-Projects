import React from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Bar } from 'react-chartjs-2';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

export const options = {
  responsive: true,
  plugins: {
    legend: {
      position: 'top'
    },
    title: {
      display: true,
      text: 'Afectiuni',
    },
  },
};

export function Chart({dataArray, labelsArray}) {
  const labels = labelsArray;
  const data = {
    labels,
    datasets: [
      {
        label: 'Numar de cazuri',
        data: dataArray,
        backgroundColor: 'rgb(5, 79, 109)',
      }
    ],
  };
  return <Bar options={options} data={data} />;
}
