import '../App.css';

function Home() {
  return (
    <div className="page">
      <div className="header">VET APP</div>
      <div className='grid-buttons'>
        <a className="bn39" href="/afectiuni"><span className="bn39span">Afectiuni intalnite</span></a>
        <a className="bn39" href="/vaccinare"><span className="bn39span">Perioade de vaccinare</span></a>
        <a className="bn39" href="/venituri"><span className="bn39span">Estimare venituri</span></a>
        <a className="bn39" href="/fidelizare"><span className="bn39span">Optiuni de fidelizare</span></a>
      </div>
    </div>
  );
}

export default Home;
