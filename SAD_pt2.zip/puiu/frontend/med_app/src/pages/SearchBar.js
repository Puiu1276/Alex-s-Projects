import React, { useState} from 'react';
import TextField from '@mui/material/TextField';
import Autocomplete from '@mui/material/Autocomplete';
import UserService from '../services/user.services';

export const SearchBar = ({species, onBreedChange}) => {
  const [searchValue, setSearchValue] = useState('');
  const [suggestions, setSugestions] = useState([]);

  const handleSearchChange = (event) => {
    setSearchValue(event.target.value);
    onBreedChange(event.target.value);
    event.preventDefault();
    UserService.getBreed(species, event.target.value).then(
        (response) => {
          setSugestions(response.data.suggestions);
        },
        (error) => {
          const resMessage =
            (error.response &&
              error.response.data &&
              error.response.data.message) ||
            error.message ||
            error.toString();
            console.log(resMessage);
        }
      );
  };

  const handleClickSugestions = (event, value) => {
    setSearchValue(value);
    onBreedChange(value);
    setSugestions([]);
  }

  return (
    <Autocomplete
      freeSolo
      options={suggestions.map((suggestion) => suggestion.label)}
      onChange={handleClickSugestions}
      value={searchValue}
      renderInput={(params) => (
        <TextField
          {...params}
          placeholder="Cauta rasa..."
            InputLabelProps={{
                shrink: false,
            }}
          variant="outlined"
          onChange={handleSearchChange}
          style={{ width: '300px', backgroundColor: 'white', fontSize: '16px', border: '1px solid gray', borderRadius: '4px' }}
        />
      )}
    />
  );
};

export default SearchBar;