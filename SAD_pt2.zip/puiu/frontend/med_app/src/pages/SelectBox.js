import * as React from 'react';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';

const styles = {
  select: {
    fontSize: '16px',
  },
  formControl: {
    width: '300px',
    backgroundColor: 'white',
    border: '1px solid gray',
    borderRadius: '4px',
    textAlign: 'left'
  },
};

export default function SelectBox({ season, onSeasonChange }) {

  const handleChange = (event) => {
    const newSeason = event.target.value;
    onSeasonChange(newSeason);
  };

  return (
    <div>
      <FormControl
        style={styles.formControl}
      >
        <Select
          value={season}
          onChange={handleChange}
          displayEmpty
          inputProps={{ 'aria-label': 'season' }}
          style={styles.select} // Setați aici stilul pentru Select
          placeholder="Alegeți anotimpul"
        >
          <MenuItem value="">
            Alegeți anotimpul
          </MenuItem>
          <MenuItem value={1}>Primavara</MenuItem>
          <MenuItem value={2}>Vara</MenuItem>
          <MenuItem value={3}>Toamna</MenuItem>
          <MenuItem value={4}>Iarna</MenuItem>
        </Select>
      </FormControl>
    </div>
  );
}