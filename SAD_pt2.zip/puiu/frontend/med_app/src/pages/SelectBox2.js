import * as React from 'react';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';

const styles = {
  select: {
    fontSize: '16px',
  },
  formControl: {
    width: '300px',
    backgroundColor: 'white',
    border: '1px solid gray',
    borderRadius: '4px',
    textAlign: 'left'
  },
};

export default function SelectBox2({ species, onSpeciesChange }) {
  
  const handleChange = (event) => {
    const newSpecies = event.target.value;
    onSpeciesChange(newSpecies);
  };

  return (
    <div>
      <FormControl
        style={styles.formControl}
      >
        <Select
          value={species}
          onChange={handleChange}
          displayEmpty
          inputProps={{ 'aria-label': 'species' }}
          style={styles.select} // Setați aici stilul pentru Select
          placeholder="Alegeți specia"
        >
        <MenuItem value="">
            Alegeți specia
          </MenuItem>
          <MenuItem value={"Caine"}>Caine</MenuItem>
          <MenuItem value={"Pisica"}>Pisica</MenuItem>
          <MenuItem value={"Porc"}>Porc</MenuItem>
          <MenuItem value={"Cal"}>Cal</MenuItem>
        </Select>
      </FormControl>
    </div>
  );
}