import * as React from 'react';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';

const styles = {
  select: {
    fontSize: '16px',
  },
  formControl: {
    width: '300px',
    backgroundColor: 'white',
    border: '1px solid gray',
    borderRadius: '4px',
    textAlign: 'left'
  },
};

export default function SelectBox3({ conditions, condition, onConditionChange }) {
  
  const handleChange = (event) => {
    const newCondition = event.target.value;
    onConditionChange(newCondition);
  };

  const elementeMenuItem = conditions.map((valoare) => (
    <MenuItem value={valoare}>
      {valoare}
    </MenuItem>
  ));

  return (
    <div>
      <FormControl
        style={styles.formControl}
      >
        <Select
          value={condition}
          onChange={handleChange}
          displayEmpty
          inputProps={{ 'aria-label': 'species' }}
          style={styles.select}
          placeholder="Alegeți specia"
        >
        <MenuItem value="">
            Alegeți afectiunea
          </MenuItem>
          {elementeMenuItem}
        </Select>
      </FormControl>
    </div>
  );
}