import { useEffect, useState } from 'react';
import '../App.css';
import SelectBox2 from './SelectBox2';
import UserService from '../services/user.services';
import SelectBox3 from './SelectBox3';

function Vaccinare() {
  const [species, setSpecies] = useState('');
  const [condition, setCondition] = useState('');
  const [conditions, setConditions] = useState([]);
  const [vaccines, setVaccines] = useState([]);

  const handleSpeciesChange = (newSpecies) => {
    setSpecies(newSpecies);
  };

  const handleConditionChange = (newCondition) => {
    setCondition(newCondition);
  };

  useEffect(() => {
        UserService.getAllConditions().then(
            (response) => {
            setConditions(response.data.conditions);
            },
            (error) => {
            const resMessage =
                (error.response &&
                error.response.data &&
                error.response.data.message) ||
                error.message ||
                error.toString();
                console.log(resMessage);
            }
        );
  });

  const buttonClick = (event) => {
    event.preventDefault();
    UserService.getVaccines(species, condition).then(
        (response) => {
          setVaccines(response.data.response);
        },
        (error) => {
          const resMessage =
            (error.response &&
              error.response.data &&
              error.response.data.message) ||
            error.message ||
            error.toString();
            console.log(resMessage);
        }
      );
  }

  const vaccinuri = vaccines.map((valoare) => (
    <div className='vaccin'>
      <div className='vaccin-text'>{valoare.vaccin}</div>
      <div className='vaccin-text'>{valoare.perioadainceput.substring(0, valoare.perioadainceput.indexOf('T'))}</div>
      <div className='vaccin-text'>{valoare.perioadasfarsit.substring(0, valoare.perioadasfarsit.indexOf('T'))}</div>
    </div>
  ));

  return (
    <div className="page-afectiuni">
      <div className="header">VET APP</div>
      <div className='afectiuni'>
        <div className='afectiuni-1'>
            <SelectBox2  species={species} onSpeciesChange={handleSpeciesChange} ></SelectBox2>
            <SelectBox3  conditions={conditions} condition={condition} onConditionChange={handleConditionChange} ></SelectBox3>
            <div className="bn39 bn10" onClick={buttonClick}><span className="bn39span">Cauta</span></div>
        </div>
        <div className='afectiuni-2'>
            {vaccinuri}
        </div>
      </div>
    </div>
  );
}

export default Vaccinare;
