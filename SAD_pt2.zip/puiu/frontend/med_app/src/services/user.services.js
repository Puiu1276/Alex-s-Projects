import axios from "axios";

const API_URL = "http://localhost:8080/";

const getBreed = (species, start) => {
  return axios.get(API_URL + "getBreed", {
    params: {
      start: start,
      species: species
    }
  });
}

const getXlsx = (opts) => {
  return axios.get(API_URL + "getXlsx", {
    responseType: 'arraybuffer',
    headers: {'Content-Type': 'blob'},
    params: {
      opts: opts
    }
  });
}

const getConditions = (season, breed, species) => {
  return axios.get(API_URL + "getConditions", {
    params: {
      season: season,
      breed: breed,
      species: species
    }
  });
}

const getVaccines = (species, condition) => {
  return axios.get(API_URL + "getVaccines", {
    params: {
      species: species,
      condition: condition
    }
  });
}

const getAllConditions = () => {
  return axios.get(API_URL + "getAllConditions");
}

const UserService = {
  getBreed,
  getConditions,
  getAllConditions,
  getVaccines,
  getXlsx
}

export default UserService;