const pool = require('../db/db');
var XLSXChart = require ("xlsx-chart");
const XLSX = require('xlsx');
const fs = require('fs');
const path = require('path');
const archiver = require('archiver');

exports.getConditions = async (req, res) => {
  const season = req.query.season;
  const breed = req.query.breed;
  const species = req.query.species;
  var month, query;
  if (season == 0) {
    res.status(200).send({nr_cazuri: [], denumiri: [], code: 1});
    return;
  } else if (season == 1) {
    month = [3, 4, 5];
  } else if (season == 2) {
    month = [6, 7, 8];
  } else if (season == 3) {
    month = [9, 10, 11];
  } else if (season == 4) {
    month = [12, 1, 2];
  }

  if (breed == "") {
    query = {
      text: 'SELECT distinct Afectiuni.denumire, Afectiuni.descriere, Afectiuni.numar_cazuri, Afectiuni.perioadainceput, Afectiuni.perioadasfarsit, Afectiuni.vaccin FROM Afectiuni ' +
          'JOIN Animale ON Afectiuni.IDAfectiune = ANY(Animale.Afectiuni) ' +
          'WHERE (EXTRACT(MONTH FROM PerioadaInceput) = ANY($1) ' +
          'OR EXTRACT(MONTH FROM PerioadaSfarsit) = ANY($1)) ' +
          'AND Animale.Specie = $2',
      values: [month, species],
    };
  } else {
    query = {
      text: 'SELECT distinct Afectiuni.denumire, Afectiuni.descriere, Afectiuni.numar_cazuri, Afectiuni.perioadainceput, Afectiuni.perioadasfarsit, Afectiuni.vaccin FROM Afectiuni ' +
          'JOIN Animale ON Afectiuni.IDAfectiune = ANY(Animale.Afectiuni) ' +
          'WHERE (EXTRACT(MONTH FROM PerioadaInceput) = ANY($1) ' +
          'OR EXTRACT(MONTH FROM PerioadaSfarsit) = ANY($1)) ' +
          'AND Animale.Rasa = $2 and Animale.Specie = $3',
      values: [month, breed, species],
    };
  }

  try {
    const response = await pool.query(query);

    var opts = {
      file: "afectiuni1.xlsx",
      chart: "column",
      titles: [],
      fields: [
        "Numar cazuri"
      ]
    };

    const listaDenumiri = response.rows.map((obiect) => obiect.denumire);
    const listaCazuri = response.rows.map((obiect) => obiect.numar_cazuri);
    const listaInceput = response.rows.map((obiect) => obiect.perioadainceput);
    const listaSfarsit = response.rows.map((obiect) => obiect.perioadasfarsit);
    const listaDescriere = response.rows.map((obiect) => obiect.descriere);
    const listaVaccin = response.rows.map((obiect) => obiect.vaccin);
    opts.titles = listaDenumiri;

    var rezultat = {};
    for (var i = 0; i < listaDenumiri.length; i++) {
      var denumire = listaDenumiri[i];
      var numarCazuri = listaCazuri[i];
      var perioadaInceput = listaInceput[i];
      var perioadaSfarsit = listaSfarsit[i];
      var descriere = listaDescriere[i];
      var vaccin = listaVaccin[i];

      rezultat[denumire] = {
        "Denumire": denumire,
        "Numar cazuri": numarCazuri,
        "Descriere": descriere,
        "Perioada Inceput": perioadaInceput,
        "Perioada Sfarsit": perioadaSfarsit,
        "Vaccin": vaccin
      };
    }
    opts.data = rezultat;

    res.status(200).send({nr_cazuri: listaCazuri, denumiri: listaDenumiri, opts: opts, code: 1});
  } catch (err) {
    console.log(err);
    res.status(404).send({message: "Error", code: 0});
  }
};

const writeFilePromise = (opts) => {
  return new Promise((resolve, reject) => {
    var xlsxChart = new XLSXChart ();
    xlsxChart.writeFile(opts, function (err) {
      if (err) {
        reject(err);
      } else {
        console.log("File: ", opts.file);
        resolve();
      }
    });
  });
};

exports.getXlsx = async (req, res) => {
  const opts = req.query.opts;
  console.log(opts);
  if (opts != {} && opts != null && opts != undefined && opts.data != undefined) {
    try {
      await writeFilePromise(opts);

      const myList = Object.values(opts.data);
      var wb = XLSX.utils.book_new();
      var ws = XLSX.utils.json_to_sheet(myList);
      XLSX.utils.book_append_sheet(wb, ws, "Afectiuni");
      await XLSX.writeFile(wb, 'afectiuni2.xlsx');

      const output = fs.createWriteStream('arhiva.zip');
      const archive = archiver('zip', { zlib: { level: 9 } });

      archive.file(path.resolve(__dirname, '..', '..', 'afectiuni1.xlsx'), { name: 'afectiuni1.xlsx' });
      archive.file(path.resolve(__dirname, '..', '..', 'afectiuni2.xlsx'), { name: 'afectiuni2.xlsx' });

      archive.pipe(output);
      archive.finalize();

      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', 'attachment; filename=arhiva.zip');

      output.on('close', () => {
        const zipStream = fs.createReadStream('arhiva.zip');
        zipStream.pipe(res);
      });
    } catch (err) {
      console.log(err);
      res.status(404).send({message: "Error", code: 0});
    }
  } else {
    res.status(200).send({message: "ok"});
  }
};

exports.getBreed = async (req, res) => {
  const start = req.query.start.toLowerCase();
  const species = req.query.species;
  if(start == "") {
    res.status(200).send({suggestions: [], code: 1});
    return;
  }

  query = {
    text: 'SELECT distinct Rasa FROM animale WHERE LOWER(Rasa) LIKE $1 and Specie = $2',
    values: [start + '%', species],
  };

  try {
    const response = await pool.query(query);
    var suggestions = response.rows;
    const modifiedSuggestions = suggestions.map((item) => {
      return { label: item.rasa };
    });
    res.status(200).send({suggestions: modifiedSuggestions, code: 1});
  } catch (err) {
    console.log(err);
    res.status(404).send({message: "Error", code: 0});
  }
};

exports.getAllConditions = async (req, res) => {
  try {
    const response = await pool.query('SELECT distinct Afectiuni.denumire FROM afectiuni');
    const listaDenumiri = response.rows.map((obiect) => obiect.denumire);
    res.status(200).send({conditions: listaDenumiri, code: 1});
  } catch (err) {
    console.log(err);
    res.status(404).send({message: "Error", code: 0});
  }
};

exports.getVaccines = async (req, res) => {
  const species = req.query.species;
  const condition = req.query.condition;
  var query;

  if (species == "" && condition != "") {
    query = {
      text: 'SELECT distinct Afectiuni.denumire, Afectiuni.PerioadaInceput, Afectiuni.PerioadaSfarsit, Afectiuni.Vaccin FROM Afectiuni ' +
          'WHERE Afectiuni.Denumire = $1',
      values: [condition],
    };
  } else if (species != "" && condition == "") {
    query = {
      text: 'SELECT distinct Afectiuni.denumire, Afectiuni.PerioadaInceput, Afectiuni.PerioadaSfarsit, Afectiuni.Vaccin FROM Afectiuni ' +
          'JOIN Animale ON Afectiuni.IDAfectiune = ANY(Animale.Afectiuni) ' +
          'WHERE Animale.Specie = $1',
      values: [species],
    };
  } else {
    query = {
      text: 'SELECT distinct Afectiuni.denumire, Afectiuni.PerioadaInceput, Afectiuni.PerioadaSfarsit, Afectiuni.Vaccin FROM Afectiuni ' +
          'JOIN Animale ON Afectiuni.IDAfectiune = ANY(Animale.Afectiuni) ' +
          'WHERE Animale.Specie = $1 AND Afectiuni.denumire = $2',
      values: [species, condition],
    };
  }

  try {
    const response = await pool.query(query);
    res.status(200).send({response: response.rows, code: 1});
  } catch (err) {
    console.log(err);
    res.status(404).send({message: "Error", code: 0});
  }
};


