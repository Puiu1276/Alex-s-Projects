const { Pool, Client } = require('pg');

const pool = new Pool({
    user: "postgres",
    host: "localhost",
    database: "postgres",
    password: "stelica",
    port: 5432
  });
  
module.exports = pool;