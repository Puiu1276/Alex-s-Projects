const controller = require("../controllers/user.controller");

module.exports = function(app) {
  app.use(function(req, res, next) {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', '*');
    if ('OPTIONS' === req.method) {
      res.send(200);
    } else {
      next();
    }
  });

  app.get("/getConditions", controller.getConditions);
  app.get("/getBreed", controller.getBreed);
  app.get("/getAllConditions", controller.getAllConditions);
  app.get("/getVaccines", controller.getVaccines);
  app.get("/getXlsx", controller.getXlsx);
};