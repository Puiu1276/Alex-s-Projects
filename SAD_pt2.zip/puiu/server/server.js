const express = require('express');
const cors = require("cors");
const path = require('path');

require('dotenv').config({
    override: true,
    path: path.join(__dirname, "db.env")
});
const pool = require('./app/db/db');

const app = express();

const corsOptions ={
  origin:'http://localhost:3000', 
  credentials:true,
  optionSuccessStatus:200
}

app.use(cors(corsOptions));

app.use(express.json({limit: '60mb'}));
app.use(express.urlencoded({limit: '60mb', extended: true}));

require("./app/routes/user.routes")(app);

const PORT = 8080;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}.`);
});

(async () => {
  try {
    const response = await pool.query("SELECT current_user");    
    const {rows} = response;
    const currentUser = rows[0]['current_user'];
    console.log(currentUser);
  } catch (err) {
    console.log(err);
  }
})();
